#include <stdio.h>

void main(void){

int termo;
int soma;
termo = 3*(3^29);
soma = ((3+termo)*30)/2;
printf("termo de 30: %i",termo);
printf("\nsoma:%i",soma);
}
