#include <stdio.h>

void main(void){


int nova=0;
int soma;



int i=0;

while(i<=1000){
    soma=i;
    nova=nova+soma;
    i=i+2;
}
printf("%d",nova);

}